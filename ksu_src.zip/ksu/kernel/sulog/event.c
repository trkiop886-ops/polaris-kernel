#define KSU_SULOG_MAX_QUEUED 256U
#define KSU_SULOG_MAX_PAYLOAD_LEN 2048U
#define KSU_SULOG_MAX_ARG_STRINGS 0x7FFFFFFF
#define KSU_SULOG_MAX_ARG_CHUNK 256U
#define KSU_SULOG_MAX_FILENAME_LEN 256U

static struct ksu_event_queue sulog_queue;

struct ksu_sulog_pending_event {
    __u16 event_type;
    void *payload;
    __u32 payload_len;
};

struct ksu_sulog_identity {
    __u32 uid;
    __u32 euid;
};

#ifdef CONFIG_KSU_SUSFS
extern const char __user *get_user_arg_ptr(struct user_arg_ptr argv, int nr);
#else
static const char __user *ksu_sulog_get_user_arg_ptr(struct user_arg_ptr argv, int nr)
{
    const char __user *native;

#ifdef CONFIG_COMPAT
    if (unlikely(argv.is_compat)) {
        compat_uptr_t compat;

        if (get_user(compat, argv.ptr.compat + nr))
            return ERR_PTR(-EFAULT);

        return compat_ptr(compat);
    }
#endif

    if (get_user(native, argv.ptr.native + nr))
        return ERR_PTR(-EFAULT);

    return native;
}
#endif

static void ksu_sulog_fill_task_info(struct ksu_sulog_event *event, __u16 event_type, int retval)
{
    event->version = KSU_SULOG_EVENT_VERSION;
    event->event_type = event_type;
    event->retval = retval;
    event->pid = task_pid_nr(current);
    event->tgid = task_tgid_nr(current);
    event->ppid = task_ppid_nr(current);
    event->uid = current_uid().val;
    event->euid = current_euid().val;
    get_task_comm(event->comm, current);
}

static void ksu_sulog_set_identity(struct ksu_sulog_event *event, const struct ksu_sulog_identity *identity)
{
    if (!identity)
        return;

    event->uid = identity->uid;
    event->euid = identity->euid;
}

static __u32 ksu_sulog_copy_empty_string(char *dst)
{
    dst[0] = '\0';
    return 1;
}

static __u32 ksu_sulog_copy_filename(const char __user *filename_user, char *dst, __u32 dst_len)
{
    long ret;

    if (!dst_len)
        return 0;

    if (!filename_user)
        return ksu_sulog_copy_empty_string(dst);

    ret = ksu_strncpy_from_user_nofault(dst, (const void __user *)untagged_addr((unsigned long)filename_user), dst_len);
    if (ret <= 0)
        return ksu_sulog_copy_empty_string(dst);

    if (ret >= dst_len) {
        dst[dst_len - 1] = '\0';
        return dst_len;
    }

    return ret + 1;
}

#ifdef CONFIG_KSU_SUSFS
static __u32 ksu_sulog_copy_filename_kernel(const char *filename, char *dst, __u32 dst_len)
{
    long ret;

    if (!dst_len)
        return 0;

    if (!filename)
        return ksu_sulog_copy_empty_string(dst);

    ret = strncpy(dst, filename, dst_len);
    if (ret <= 0)
        return ksu_sulog_copy_empty_string(dst);

    if (ret >= dst_len) {
        dst[dst_len - 1] = '\0';
        return dst_len;
    }

    return ret + 1;
}

static __u32 ksu_sulog_flatten_argv(struct user_arg_ptr *argv_user, char *dst, __u32 dst_len)
{
    char arg[KSU_SULOG_MAX_ARG_CHUNK];
    __u32 used = 0;
    int i;

    if (!dst_len)
        return 0;

    if (!argv_user)
        return ksu_sulog_copy_empty_string(dst);

    for (i = 0; i < KSU_SULOG_MAX_ARG_STRINGS; i++) {
        const char __user *arg_user;
        long copied;
        size_t arg_len;

        if (fatal_signal_pending(current))
            break;

        arg_user = get_user_arg_ptr(*argv_user, i);
        if (!arg_user)
            break;
        if (IS_ERR(arg_user))
            return ksu_sulog_copy_empty_string(dst);

        copied =
            strncpy_from_user_nofault(arg, (const void __user *)untagged_addr((unsigned long)arg_user), sizeof(arg));
        if (copied <= 0)
            return ksu_sulog_copy_empty_string(dst);

        if (copied >= sizeof(arg))
            arg[sizeof(arg) - 1] = '\0';

        arg_len = strnlen(arg, sizeof(arg));
        if (!arg_len)
            continue;

        if (used && used < dst_len - 1)
            dst[used++] = ' ';

        if (used >= dst_len - 1)
            break;

        arg_len = min_t(size_t, arg_len, dst_len - used - 1);
        memcpy(dst + used, arg, arg_len);
        used += arg_len;

        if (used >= dst_len - 1)
            break;
    }

    dst[used] = '\0';
    return used + 1;
}

static struct ksu_sulog_pending_event *ksu_sulog_capture(__u16 event_type, const char *filename,
                                                         struct user_arg_ptr *argv_user, gfp_t gfp)
{
    struct ksu_sulog_pending_event *pending = NULL;
    struct ksu_sulog_event *event;
    void *payload = NULL;
    __u32 payload_len;
    __u32 filename_len;
    __u32 argv_len;
    __u32 remaining;
    char *filename_buf;
    char *argv_buf;

    if (!ksu_sulog_is_enabled())
        return NULL;

    pending = kzalloc(sizeof(*pending), gfp);
    if (!pending)
        goto out_drop;

    payload = kzalloc(KSU_SULOG_MAX_PAYLOAD_LEN, gfp);
    if (!payload)
        goto out_free_pending;

    event = payload;
    ksu_sulog_fill_task_info(event, event_type, 0);

    remaining = KSU_SULOG_MAX_PAYLOAD_LEN - sizeof(*event);
    filename_buf = (char *)payload + sizeof(*event);
    filename_len = ksu_sulog_copy_filename_kernel(filename, filename_buf, min(remaining, KSU_SULOG_MAX_FILENAME_LEN));
    if (!filename_len)
        goto out_free_payload;

    remaining -= filename_len;
    argv_buf = filename_buf + filename_len;
    argv_len = ksu_sulog_flatten_argv(argv_user, argv_buf, remaining);
    if (!argv_len)
        goto out_free_payload;

    event->filename_len = filename_len;
    event->argv_len = argv_len;

    if (check_add_overflow((__u32)sizeof(*event), filename_len, &payload_len) ||
        check_add_overflow(payload_len, argv_len, &payload_len))
        goto out_free_payload;

    pending->event_type = event_type;
    pending->payload = payload;
    pending->payload_len = payload_len;
    return pending;

out_free_payload:
    kfree(payload);
out_free_pending:
    kfree(pending);
out_drop:
    ksu_event_queue_drop(&sulog_queue);
    return NULL;
}
#else
static __u32 ksu_sulog_flatten_argv(struct user_arg_ptr argv, char *dst, __u32 dst_len)
{
    char arg[KSU_SULOG_MAX_ARG_CHUNK];
    __u32 used = 0;
    int i;

    if (!dst_len)
        return 0;

    if (!argv.ptr.native)
        return ksu_sulog_copy_empty_string(dst);

    for (i = 0; i < KSU_SULOG_MAX_ARG_STRINGS; i++) {
        const char __user *arg_user;
        long copied;
        size_t arg_len;

        if (fatal_signal_pending(current))
            break;

        arg_user = ksu_sulog_get_user_arg_ptr(argv, i);
        if (!arg_user)
            break;
        if (IS_ERR(arg_user))
            return ksu_sulog_copy_empty_string(dst);

        copied = ksu_strncpy_from_user_nofault(arg, (const void __user *)untagged_addr((unsigned long)arg_user),
                                               sizeof(arg));
        if (copied <= 0)
            return ksu_sulog_copy_empty_string(dst);

        if (copied >= sizeof(arg))
            arg[sizeof(arg) - 1] = '\0';

        arg_len = strnlen(arg, sizeof(arg));
        if (!arg_len)
            continue;

        if (used && used < dst_len - 1)
            dst[used++] = ' ';

        if (used >= dst_len - 1)
            break;

        arg_len = min_t(size_t, arg_len, dst_len - used - 1);
        memcpy(dst + used, arg, arg_len);
        used += arg_len;

        if (used >= dst_len - 1)
            break;
    }

    dst[used] = '\0';
    return used + 1;
}
static struct ksu_sulog_pending_event *ksu_sulog_capture(__u16 event_type, const char __user *filename_user,
                                                         const struct user_arg_ptr argv, gfp_t gfp)
{
    struct ksu_sulog_pending_event *pending = NULL;
    struct ksu_sulog_event *event;
    void *payload = NULL;
    __u32 payload_len;
    __u32 filename_len;
    __u32 argv_len;
    __u32 remaining;
    char *filename_buf;
    char *argv_buf;
    bool should_skip_copy = false;

    if (!ksu_sulog_is_enabled())
        return NULL;

    if (event_type == KSU_SULOG_EVENT_IOCTL_GRANT_ROOT) {
        filename_len = 0;
        argv_len = 0;
        should_skip_copy = true;
    }

    // alloc memory
    pending = kzalloc(sizeof(*pending), gfp);
    if (!pending)
        goto out_drop;

    payload = kzalloc(KSU_SULOG_MAX_PAYLOAD_LEN, gfp);
    if (!payload)
        goto out_free_pending;

    event = payload;
    ksu_sulog_fill_task_info(event, event_type, 0);

    if (should_skip_copy)
        goto skip_copy;

    remaining = KSU_SULOG_MAX_PAYLOAD_LEN - sizeof(*event);
    filename_buf = (char *)payload + sizeof(*event);
    filename_len = ksu_sulog_copy_filename(filename_user, filename_buf, min(remaining, KSU_SULOG_MAX_FILENAME_LEN));
    if (!filename_len)
        goto out_free_payload;

    remaining -= filename_len;
    argv_buf = filename_buf + filename_len;

    argv_len = ksu_sulog_flatten_argv(argv, argv_buf, remaining);
    if (!argv_len)
        goto out_free_payload;

skip_copy:
    // put event information
    event->filename_len = filename_len;
    event->argv_len = argv_len;

    if (check_add_overflow((__u32)sizeof(*event), filename_len, &payload_len) ||
        check_add_overflow(payload_len, argv_len, &payload_len))
        goto out_free_payload;

    pending->event_type = event_type;
    pending->payload = payload;
    pending->payload_len = payload_len;
    return pending;

out_free_payload:
    kfree(payload);
out_free_pending:
    kfree(pending);
out_drop:
    ksu_event_queue_drop(&sulog_queue);
    return NULL;
}
#endif

#ifdef CONFIG_KSU_SUSFS
static inline struct user_arg_ptr *user_arg_null_ptr(void)
{
    static struct user_arg_ptr null_arg = { 0 };
    return &null_arg;
}
#else
static inline struct user_arg_ptr user_arg_null_ptr(void)
{
    struct user_arg_ptr null_arg = { 0 };
    return null_arg;
}
#endif

static struct ksu_sulog_pending_event *ksu_sulog_capture_grant_root(const struct ksu_sulog_identity *identity,
                                                                    gfp_t gfp)
{
    struct ksu_sulog_pending_event *pending;
    struct ksu_sulog_event *event;

    // This is actually stupid fix
    #define USER_ARG_NULL user_arg_null_ptr()

    pending = ksu_sulog_capture(KSU_SULOG_EVENT_IOCTL_GRANT_ROOT, NULL, USER_ARG_NULL, gfp);
    if (!pending)
        return NULL;

    event = pending->payload;
    ksu_sulog_set_identity(event, identity);
    return pending;
}

int __init ksu_sulog_events_init(void)
{
    ksu_event_queue_init(&sulog_queue, KSU_SULOG_MAX_QUEUED, KSU_SULOG_MAX_PAYLOAD_LEN);
    return 0;
}

void __exit ksu_sulog_events_exit(void)
{
    ksu_event_queue_destroy(&sulog_queue);
}

static void ksu_sulog_free_pending(struct ksu_sulog_pending_event *pending)
{
    if (!pending)
        return;
    kfree(pending->payload);
    kfree(pending);
}

#ifdef CONFIG_KSU_SUSFS
struct ksu_sulog_pending_event *ksu_sulog_capture_sucompat(const char *filename,
                                                           struct user_arg_ptr *argv_user, gfp_t gfp)
{
    return ksu_sulog_capture(KSU_SULOG_EVENT_SUCOMPAT, filename, argv_user, gfp);
}
#else
struct ksu_sulog_pending_event *ksu_sulog_capture_root_execve(const char __user *filename_user,
                                                              const struct user_arg_ptr argv, gfp_t gfp)
{
    return ksu_sulog_capture(KSU_SULOG_EVENT_ROOT_EXECVE, filename_user, argv, gfp);
}

struct ksu_sulog_pending_event *ksu_sulog_capture_sucompat(const char __user *filename_user,
                                                           const struct user_arg_ptr argv, gfp_t gfp)
{
    return ksu_sulog_capture(KSU_SULOG_EVENT_SUCOMPAT, filename_user, argv, gfp);
}
#endif

void ksu_sulog_emit_pending(struct ksu_sulog_pending_event *pending, int retval, gfp_t gfp)
{
    struct ksu_sulog_event *event;

    if (!pending)
        return;

    event = pending->payload;
    event->retval = retval;
    ksu_event_queue_push(&sulog_queue, pending->event_type, 0, pending->payload, pending->payload_len, gfp);
    ksu_sulog_free_pending(pending);
}

int ksu_sulog_emit_grant_root(int retval, __u32 uid, __u32 euid, gfp_t gfp)
{
    struct ksu_sulog_pending_event *pending;
    struct ksu_sulog_identity identity = {
        .uid = uid,
        .euid = euid,
    };

    pending = ksu_sulog_capture_grant_root(&identity, gfp);
    if (!pending)
        return 0;

    ksu_sulog_emit_pending(pending, retval, gfp);
    return 0;
}

struct ksu_event_queue *ksu_sulog_get_queue(void)
{
    return &sulog_queue;
}
