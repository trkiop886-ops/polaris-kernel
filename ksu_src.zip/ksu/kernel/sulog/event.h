#ifndef __KSU_H_SULOG_EVENT
#define __KSU_H_SULOG_EVENT

struct ksu_event_queue;
struct ksu_sulog_pending_event;

int ksu_sulog_events_init(void);
void ksu_sulog_events_exit(void);

#ifdef CONFIG_KSU_SUSFS
struct ksu_sulog_pending_event *ksu_sulog_capture_sucompat(const char *filename,
                                                           struct user_arg_ptr *argv_user, gfp_t gfp);
#else
struct ksu_sulog_pending_event *ksu_sulog_capture_root_execve(const char __user *filename,
                                                                     const struct user_arg_ptr argv, gfp_t gfp);
struct ksu_sulog_pending_event *ksu_sulog_capture_sucompat(const char __user *filename, const struct user_arg_ptr argv,
                                                                  gfp_t gfp);
#endif
void ksu_sulog_emit_pending(struct ksu_sulog_pending_event *pending, int retval, gfp_t gfp);
int ksu_sulog_emit_grant_root(int retval, __u32 uid, __u32 euid, gfp_t gfp);

struct ksu_event_queue *ksu_sulog_get_queue(void);

#endif
