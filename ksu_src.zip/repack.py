#!/usr/bin/env python3
# 用新内核(Image 或 Image.gz)替换 boot.img 里的内核，保持原有 header / ramdisk / AVB 结构
import sys, struct, gzip, io, os
orig_path, new_kernel_path, out_path = sys.argv[1], sys.argv[2], sys.argv[3]
d = open(orig_path,'rb').read()
ks,ka,rs,ra,ss,sa,ta,pg = struct.unpack('<8I', d[8:40])
hv,osv = struct.unpack('<II', d[40:48])
assert d[:8]==b'ANDROID!'
def pad(x,p): return x + b'\0'*((p-len(x)%p)%p)
# 取原 ramdisk
kern_pages=(ks+pg-1)//pg
rd_off = pg + kern_pages*pg
ramdisk = d[rd_off:rd_off+rs]
# 新内核：若是裸 Image 则 gzip 压缩，保持内核为 gz（与原格式一致）
nk = open(new_kernel_path,'rb').read()
if nk[:2]==b'\x1f\x8b':
    kernel = nk
else:
    buf = io.BytesIO()
    with gzip.GzipFile(fileobj=buf, mode='wb', compresslevel=9, mtime=0) as g:
        g.write(nk)
    kernel = buf.getvalue()
new_ks = len(kernel)
# 重新组装 header（原样复制，仅改 kernel_size）
hdr = bytearray(d[:pg])
struct.pack_into('<I', hdr, 8, new_ks)
# 组装 image 主体: header + kernel(pad) + ramdisk(pad) [+ second(pad)]
body = bytes(hdr) + pad(kernel,pg) + pad(ramdisk,pg)
# 原 AVB 结构
f = len(d)-64
be = lambda o,n: int.from_bytes(d[o:o+n],'big')
vbmeta_size = be(f+28,8)
vbmeta = d[be(f+20,8):be(f+20,8)+vbmeta_size]
part_size = len(d)
orig_img_size = len(body)
new_img_size = orig_img_size
# vbmeta 紧跟 image 主体，之后补零到 part_size-64，最后 footer
out = bytearray()
out += body
out += b'\0'*((8 - len(out)%8)%8)   # avbtool 会做 8 字节对齐
vbo = len(out)
out += vbmeta
pad_to = part_size - 64
if len(out) > pad_to: raise SystemExit("image too big")
out += b'\0'*(pad_to-len(out))
foot = bytearray(d[f:f+64])
foot[12:20] = new_img_size.to_bytes(8,'big')   # original_image_size
foot[20:28] = vbo.to_bytes(8,'big')            # vbmeta_offset
foot[28:36] = len(vbmeta).to_bytes(8,'big')    # vbmeta_size
out += bytes(foot)
open(out_path,'wb').write(bytes(out))
print(f"[ok] {out_path}  size={len(out)}  kernel {ks} -> {new_ks}")
