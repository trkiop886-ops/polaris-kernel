#!/bin/bash
# ============================================================
# MIX2S (polaris) SukiSU Ultra 内核一键构建 + boot 重打包
# 环境变量(全部可选，默认适配本工作区):
#   KSRC     内核源码目录        (默认 /workspace/kernel_src)
#   BOOT     原 boot.img         (默认 /workspace/boot.img)
#   SUKISU   SukiSU 源码目录      (默认 /workspace/SukiSU)
#   KCONFIG  设备 .config         (默认 /workspace/utopia.config)
#   OUT      输出 boot.img        (默认 /workspace/boot_sukisu.img)
#   JOB      并行度              (默认 $(nproc))
#   CLANG_BIN / CROSS64_BIN / CROSS32_BIN  交叉工具链 bin 目录(自己机器上可选)
# ============================================================
# 用 sh 调用时自动换成 bash
if [ -z "${BASH_VERSION:-}" ]; then exec bash "$0" "$@"; fi
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"

# -------- 自动定位内核源码 --------
if [ -z "${KSRC:-}" ]; then
  for d in "$HERE"/android_kernel_xiaomi_sdm845* "$HERE"/*sdm845* "$HERE"/kernel_src "$HERE"/ksrc "$HERE"/src "$HERE"/linux*; do
    if [ -f "$d/Makefile" ] && grep -q "^PATCHLEVEL = 9" "$d/Makefile" 2>/dev/null; then KSRC="$d"; break; fi
  done
fi
if [ -z "${KSRC:-}" ] || [ ! -d "$KSRC" ]; then
  echo "!! 找不到内核源码目录。"
  echo "   把 LineageOS 源码解压到本脚本同目录，或手动指定："
  echo "     export KSRC=/path/to/android_kernel_xiaomi_sdm845-lineage-21"
  echo "   脚本目录: $HERE"
  echo "   目录内容: $(ls "$HERE" 2>/dev/null | head -20 | tr '\n' ' ')"
  exit 1
fi
KCONFIG="${KCONFIG:-$HERE/utopia.config}"
SUKISU="${SUKISU:-$HERE/SukiSU_kernel_patched}"
BOOT="${BOOT:-}"
OUT="${OUT:-$HERE/boot_sukisu.img}"
JOB="${JOB:-$(nproc)}"
echo "==> KSRC   = $KSRC"
echo "==> KCONFIG= $KCONFIG"
echo "==> SUKISU = $SUKISU"
echo "==> JOB    = $JOB"
[ -n "$BOOT" ] && echo "==> BOOT   = $BOOT"
miss=""
for t in make python3 bc bison flex; do command -v $t >/dev/null 2>&1 || miss="$miss $t"; done
[ -n "$miss" ] && { echo "!! 缺少工具:$miss (apt install make python3 bc bison flex libssl-dev libelf-dev cpio)"; exit 1; }
[ -f "$KCONFIG" ] || { echo "!! 找不到配置文件 $KCONFIG"; exit 1; }
[ -d "$SUKISU" ]  || { echo "!! 找不到 SukiSU 源码 $SUKISU"; exit 1; }
cd "$KSRC" || exit 1

echo "==> [1/5] 集成 SukiSU(builtin) 到内核树"
rm -rf KernelSU drivers/kernelsu
mkdir -p KernelSU
cp -r "$SUKISU/kernel" KernelSU/kernel
ln -sf ../KernelSU/kernel drivers/kernelsu
grep -q "CONFIG_KSU" drivers/Makefile || echo 'obj-$(CONFIG_KSU) += kernelsu/' >> drivers/Makefile
grep -q 'drivers/kernelsu/Kconfig' drivers/Kconfig || sed -i '/^endmenu/i source "drivers/kernelsu/Kconfig"' drivers/Kconfig

echo "==> [2/5] 修 kbuild 头文件搜索路径(尖括号本地头)"
python3 - <<'PY'
p='scripts/Makefile.lib'
s=open(p).read()
a="ifeq ($(KBUILD_SRC),)\n__c_flags\t= $(_c_flags)"
b="ifeq ($(KBUILD_SRC),)\n__c_flags\t= -I$(srctree)/$(src) $(_c_flags)"
if a in s: s=s.replace(a,b,1)
open(p,'w').write(s)
PY

echo "==> [3/5] 写入配置(原厂配置 + KSU + vermagic 伪装)"
cp "$KCONFIG" .config
./scripts/config --file .config \
    -d DEBUG_INFO -d DEBUG_INFO_REDUCED -d DEBUG_INFO_SPLIT -d CC_WERROR \
    -e KSU -d KSU_SUSFS \
    --set-str LOCALVERSION "-perf-g88606771eef3" \
    -d LOCALVERSION_AUTO
make ARCH=arm64 olddefconfig >/dev/null

echo "==> [4/5] 选择工具链"
if [ -n "${CLANG_BIN:-}" ] && [ -d "$CLANG_BIN" ]; then
    export PATH="$CLANG_BIN:$PATH"
    CC=clang; CLANG_TRIPLE="aarch64-linux-gnu-"; LD="ld.lld"
    for t in llvm-ar llvm-nm llvm-objcopy llvm-objdump llvm-strip llvm-readelf; do
        command -v $t >/dev/null && eval "T_${t%%-*}=\$t"
    done
    if [ -n "${CROSS64_BIN:-}" ] && [ -d "$CROSS64_BIN" ]; then
        CROSS_COMPILE="$(basename "$(ls "$CROSS64_BIN"/*-gcc | head -1)" -gcc)-"
    else
        CROSS_COMPILE="aarch64-linux-gnu-"
    fi
    if [ -n "${CROSS32_BIN:-}" ] && [ -d "$CROSS32_BIN" ]; then
        CROSS_COMPILE_ARM32="$(basename "$(ls "$CROSS32_BIN"/*-gcc | head -1)" -gcc)-"
    else
        CROSS_COMPILE_ARM32="arm-linux-gnueabi-"
    fi
    echo "    clang: $(command -v clang)"
elif command -v gcc-9 >/dev/null 2>&1; then
    CC=gcc-9; CROSS_COMPILE=""; CROSS_COMPILE_ARM32="arm-linux-gnueabi-"; LD=""
    echo "    native gcc-9"
elif command -v aarch64-linux-gnu-gcc >/dev/null 2>&1; then
    CC="aarch64-linux-gnu-gcc"; CROSS_COMPILE="aarch64-linux-gnu-"; CROSS_COMPILE_ARM32="arm-linux-gnueabi-"; LD=""
    echo "    aarch64-linux-gnu-gcc"
elif command -v clang >/dev/null 2>&1; then
    CC=clang; CROSS_COMPILE=""; CROSS_COMPILE_ARM32=""; CLANG_TRIPLE="aarch64-linux-gnu-"; LD=""
    echo "    native clang: $(clang --version 2>/dev/null | head -1)"
else
    echo "!! 没有可用编译器"; exit 1
fi
# ---- 没有 arm32 交叉编译器时: 关掉 compat vDSO (32 位应用照常能用) ----
if [ -z "${CROSS_COMPILE_ARM32:-}" ] || ! command -v "${CROSS_COMPILE_ARM32}gcc" >/dev/null 2>&1; then
    echo "!! 未找到 arm32 交叉编译器 ${CROSS_COMPILE_ARM32}gcc"
    echo "   -> 自动关闭 CONFIG_COMPAT_VDSO (32 位 app 不受影响, 只是少了 vdso 加速)"
    ./scripts/config --file .config -d COMPAT_VDSO
    make ARCH=arm64 olddefconfig >/dev/null
    CROSS_COMPILE_ARM32=""
fi

echo "==> [5/5] 编译 Image(断点续编, 被杀自动重试)"
BUILD_LOG=$HOME/ksu_build.log
for n in $(seq 1 60); do
    echo "----- attempt $n $(date +%T) -----"
    set +e
    make -j"$JOB" ARCH=arm64 CC="$CC" CROSS_COMPILE="$CROSS_COMPILE" \
         CROSS_COMPILE_ARM32="$CROSS_COMPILE_ARM32" \
         ${LD:+LD="$LD"} ${CLANG_TRIPLE:+CLANG_TRIPLE="$CLANG_TRIPLE"} \
         ${T_ar:+AR="$T_ar"} ${T_nm:+NM="$T_nm"} ${T_objcopy:+OBJCOPY="$T_objcopy"} \
         ${T_objdump:+OBJDUMP="$T_objdump"} ${T_strip:+STRIP="$T_strip"} \
         Image 2>&1 | tee "$BUILD_LOG"
    rc=${PIPESTATUS[0]}
    set -e
    [ -f arch/arm64/boot/Image ] && break
    if grep -qE "\.(c|h|S):[0-9]+:[0-9]+: (error|fatal error)" "$BUILD_LOG"; then
        echo "!! 真实编译错误, 停止"; tail -40 "$BUILD_LOG"; exit 1
    fi
    echo "!! attempt $n 中断(rc=$rc), 3s 后续编..."
    sleep 3
done
if [ ! -f arch/arm64/boot/Image ]; then
    echo "!! 编译失败, 请查看上面错误"; exit 1
fi
ls -la arch/arm64/boot/Image
gzip -9c arch/arm64/boot/Image > arch/arm64/boot/Image.gz

if [ -z "$BOOT" ]; then
  echo "==> 没给 BOOT(原 boot.img)，跳过重打包。"
  echo "   内核镜像: $KSRC/arch/arm64/boot/Image.gz"
  echo "   把它发回来我帮你打包；或设置 BOOT=/path/to/boot.img 后重跑"
  exit 0
fi
echo "==> 重打包 boot.img (保持原 header/ramdisk/AVB, 只换内核)"
python3 - "$BOOT" arch/arm64/boot/Image.gz "$OUT" <<'PY'
import sys, struct
orig, kern, out = sys.argv[1], sys.argv[2], sys.argv[3]
d = open(orig,'rb').read()
ks,ka,rs,ra,ss,sa,ta,pg = struct.unpack('<8I', d[8:40])
def pad(x,p): return x + b'\0'*((p-len(x)%p)%p)
ramdisk = d[pg+((ks+pg-1)//pg)*pg : pg+((ks+pg-1)//pg)*pg+rs]
kernel  = open(kern,'rb').read()
hdr = bytearray(d[:pg]); struct.pack_into('<I', hdr, 8, len(kernel))
body = bytes(hdr) + pad(kernel,pg) + pad(ramdisk,pg)
f = len(d)-64
be = lambda o,n: int.from_bytes(d[o:o+n],'big')
vbs = be(f+28,8); vb = d[be(f+20,8):be(f+20,8)+vbs]
outb = bytearray(body)
outb += b'\0'*((-len(outb))%8)
vbo = len(outb); outb += vb
padto = len(d)-64
assert len(outb) <= padto, "too big"
outb += b'\0'*(padto-len(outb))
foot = bytearray(d[f:f+64])
foot[12:20]=len(body).to_bytes(8,'big')
foot[20:28]=vbo.to_bytes(8,'big')
foot[28:36]=len(vb).to_bytes(8,'big')
outb += bytes(foot)
open(out,'wb').write(bytes(outb))
print(f"[ok] {out}  size={len(outb)}  kernel={ks}->{len(kernel)}")
PY

echo "==> 完成"
echo "产物: $OUT"
echo "刷入: fastboot flash boot $OUT  (建议先备份原 boot)"
